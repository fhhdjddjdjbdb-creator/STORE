const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "456891";
const DATA_FILE = path.join(__dirname, "data.json");

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

function readData(){
  if(!fs.existsSync(DATA_FILE)){
    const initial={settings:{siteName:"متصفح خفي",siteDesc:"متصفحك الخاص",maintenance:false,maintenanceMsg:"توقف الموقع مؤقتًا",searchEngine:"google",engines:[{id:"google",name:"Google",url:"https://www.google.com/search?q="},{id:"bing",name:"Bing",url:"https://www.bing.com/search?q="},{id:"duckduckgo",name:"DuckDuckGo",url:"https://duckduckgo.com/?q="},{id:"brave",name:"Brave",url:"https://search.brave.com/search?q="},{id:"ecosia",name:"Ecosia",url:"https://www.ecosia.org/search?q="},{id:"yahoo",name:"Yahoo",url:"https://search.yahoo.com/search?p="}]},stats:{users:0,visits:0,searches:0},support:[],users:[]};
    fs.writeFileSync(DATA_FILE,JSON.stringify(initial,null,2));
    return initial;
  }
  return JSON.parse(fs.readFileSync(DATA_FILE,"utf8"));
}
function writeData(d){fs.writeFileSync(DATA_FILE,JSON.stringify(d,null,2))}
const sessions=new Map();

function auth(req,res,next){
  const h=req.headers.authorization||"";
  const t=h.startsWith("Bearer ")?h.slice(7):"";
  if(!sessions.has(t)) return res.status(401).json({error:"جلسة المدير غير صالحة"});
  next();
}

app.post("/api/login",(req,res)=>{
  if(req.body.password!==ADMIN_PASSWORD) return res.status(401).json({error:"كلمة المرور غير صحيحة"});
  const token=crypto.randomBytes(32).toString("hex");
  sessions.set(token,Date.now());
  res.json({token});
});

app.get("/api/stats",auth,(req,res)=>{
  const d=readData(); res.json(d.stats);
});
app.get("/api/settings",auth,(req,res)=>res.json(readData().settings));
app.put("/api/settings",auth,(req,res)=>{
  const d=readData(); d.settings={...d.settings,...req.body}; writeData(d); res.json(d.settings);
});
app.get("/api/support",auth,(req,res)=>res.json({messages:readData().support}));

app.get("/api/users",auth,(req,res)=>res.json({users:readData().users||[]}));
app.put("/api/users/:id/block",auth,(req,res)=>{
  const d=readData(); d.users=d.users||[];
  const u=d.users.find(x=>x.id===req.params.id);
  if(!u) return res.status(404).json({error:"المستخدم غير موجود"});
  u.blocked=!!req.body.blocked; u.updatedAt=new Date().toISOString(); writeData(d); res.json(u);
});

app.get("/api/engines",auth,(req,res)=>res.json({engines:readData().settings.engines||[]}));
app.post("/api/engines",auth,(req,res)=>{
  const name=String(req.body.name||"").trim(), url=String(req.body.url||"").trim();
  if(!name||!url) return res.status(400).json({error:"اسم ورابط المحرك مطلوبان"});
  const d=readData(); d.settings.engines=d.settings.engines||[];
  const id="custom-"+crypto.randomBytes(5).toString("hex"); d.settings.engines.push({id,name,url}); writeData(d); res.json({id,name,url});
});
app.delete("/api/engines/:id",auth,(req,res)=>{
  const d=readData(); d.settings.engines=(d.settings.engines||[]).filter(x=>x.id!==req.params.id);
  if(d.settings.searchEngine===req.params.id) d.settings.searchEngine=d.settings.engines[0]?.id||"google";
  writeData(d); res.json({ok:true,settings:d.settings});
});


// هذه النقطتان يستخدمهما الموقع نفسه لاحقًا عند ربط index.html
app.post("/api/visit",(req,res)=>{
  const d=readData(); const id=String(req.body.userId||req.ip||"unknown"); d.users=d.users||[];
  let u=d.users.find(x=>x.id===id); if(!u){u={id,blocked:false,createdAt:new Date().toISOString(),visits:0,searches:0};d.users.push(u);}
  u.visits=(u.visits||0)+1; d.stats.visits++; d.stats.users=d.users.length; writeData(d); res.json({ok:true,blocked:!!u.blocked,maintenance:!!d.settings.maintenance});
});
app.post("/api/search",(req,res)=>{
  const d=readData(); const id=String(req.body.userId||req.ip||"unknown"); d.users=d.users||[];
  let u=d.users.find(x=>x.id===id); if(!u){u={id,blocked:false,createdAt:new Date().toISOString(),visits:0,searches:0};d.users.push(u);}
  u.searches=(u.searches||0)+1; d.stats.searches++; d.stats.users=d.users.length; writeData(d); res.json({ok:true,blocked:!!u.blocked,maintenance:!!d.settings.maintenance});
});
app.post("/api/support",(req,res)=>{
  const d=readData(); d.support.unshift({sessionId:String(req.body.sessionId||"unknown"),message:String(req.body.message||""),time:new Date().toISOString()});
  d.support=d.support.slice(0,500); writeData(d); res.json({ok:true});
});

app.get("/api/public-settings",(req,res)=>res.json(readData().settings));

app.listen(PORT,"0.0.0.0",()=>console.log(`Admin API running on port ${PORT}`));
